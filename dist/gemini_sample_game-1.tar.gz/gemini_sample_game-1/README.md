# gemini_sample_game

A sample game with Google Gemini AI integrated into it.

Pre-requisites:

1. Python installed in your device.
2. .env file in the same directory as <GEMINI_SAMPLE_GAME_DIRECTORY> and has the value of GEMINI_API_KEY.

Note: Replace <GEMINI_SAMPLE_GAME_DIRECTORY> with the path to the directory of the game **Gemini Sample Game**.